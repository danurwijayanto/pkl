<?php
	$lang["sejarah"] = "History";
	$lang["visimisi"] = "Vision and Mission";
	$lang["tujuan"] = "Goal";
	$lang["loggomotto"] = "Loggo and Motto	";
	$lang["strukturorganisasi"] = "Organization";
	$lang["kepegawaian"] = "Employee";
	$lang["guru"] = "Teachers";
	$lang["karyawan"] = "Employee";
	$lang["pengumuman"] = "Anouncement";
	$lang["agendaterdekat"] = "Agenda";
	$lang["berita"] = "News";
	$lang["artikel"] = "Article";
	$lang["informasi"] = "Information";
	$lang["kemitraan"] = "Partnerships";
	$lang["perguruan"] = "College";
	$lang["pemerintah"] = "Government";
	$lang["masyarakat"] = "Society";
	$lang["bahanajar"] = "Teaching Materials";
	$lang["materibelajar"] = "Learning Materials";
	$lang["mediabelajar"] = "Instructional Media";
	$lang["kontak"] = "Contact";
	$lang["tautan"] = "Links";
	$lang["staff"] = "Staff";
	$lang["kualitasmanagemen"] = "Quality Management";
	$lang["kurikulum"] = "Curriculum";
	$lang["student"] = "Student";
	$lang["infrastruktur"] = "Infrastructure";
	$lang["humas"] = "Public Relations";
	$lang["lihatsemua"] = "See More";
	$lang["slidertaktersedia"] = "Slider Image Not Found";
	$lang["tidakadapost"] = "Post not Found";



