<?php
require_once('admin_header.php');
require_once('admin_sidebar_kiri.php');
require_once('admin_konten.php');
require_once('admin_footer.php');

