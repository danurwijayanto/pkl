<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
  if(isset($sidebar_kanan)){
    $this->load->view($sidebar_kanan);
  }