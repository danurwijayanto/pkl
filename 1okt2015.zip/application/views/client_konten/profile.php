<!--Start Content Page-->
		<div class="container">
			<div class="content">
				<div class="row clearfix">
					<div class="col-md-8">
						<?php echo "<h2 style='text-align: center;'>".$konten['judul']."</h2><br>"?>
						<?php echo $konten['text'];?>
					</div>