<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	if(isset($isi)){
 		$this->load->view($isi);
	}