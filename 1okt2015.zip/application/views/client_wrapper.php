<?php

require_once('client_header.php');
//require_once('client_sidebar_kiri.php');
require_once('client_konten.php');
require_once('client_sidebar_kanan.php');
require_once('client_footer.php');